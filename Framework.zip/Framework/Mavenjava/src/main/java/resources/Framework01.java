package resources;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Framework01 {
	public WebDriver driver;
	public Properties prop;
	public WebDriver initilizeDriver() throws IOException
	{
		Properties prop=new Properties();
		FileInputStream fis= new FileInputStream (("E:\\selenium-java\\seleintro\\Mavenjava\\src\\main\\java\\resources\\dataProperties"));
		prop.load(fis);
		String BrowserName= prop.getProperty("url");
System.out.println(BrowserName);
		if (BrowserName.equals("Chrome"))
		{
			//execute chrome
			System.setProperty("webdriver.chrome.driver", "C:\\Users\\krishna\\Downloads\\chromedriver_win32\\chromedriver.exe");
			 driver=new ChromeDriver(); 
		}
		else if(BrowserName.equals("Firefox"))
			
		{
			//execute firefox
			System.setProperty("webdriver.gecko.driver", "C:\\Users\\krishna\\Downloads\\geckodriver-v0.30.0-win32\\geckodriver.exe");
		 driver=new FirefoxDriver();
		}
		else if (BrowserName.equals("Edge"))
		{
			System.setProperty("webdriver.edge.driver", "C:\\Users\\krishna\\Downloads\\edgedriver_win64 (1)\\msedgedriver.exe");
			 driver=new EdgeDriver();

}
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		return driver;
		
		
}
}