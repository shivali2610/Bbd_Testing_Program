package Practice.Mavenjava;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import resources.Framework01;

public class loginPage extends Framework01 {
	
	public WebDriver driver;
	By login =By.id("email");
	By logpassword =By.id("password");
	public loginPage (WebDriver driver)
	{
		this.driver=driver;
	}
public WebElement getLogin()
{
	return driver.findElement(login);
}

public WebElement getpassword()
{
	return driver.findElement(logpassword);
}
	
}

