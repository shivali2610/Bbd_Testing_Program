package Practice.Mavenjava;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import resources.Framework01;

public class homeObject extends Framework01 {
	public WebDriver driver;
	By signin=By.cssSelector("a[href*='theme-btn']");
	public homeObject (WebDriver driver)
	{
		this.driver=driver;
	}
public WebElement getLogin()
{
	return driver.findElement(signin);
}
By title=By.cssSelector(".sticky-header");
public WebElement gettitle()
{
	return (WebElement) driver.findElements(title);
	
}
}
	
	


