package Practice.Mavenjava;

import static org.testng.Assert.assertEquals;
import java.io.IOException;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.testng.annotations.Test;

import resources.Framework01;

public class validation extends Framework01
{
	public static Logger Log=LogManager.getLogger(Framework01.class.getName());
@Test

	 public void FrameworkNavigation(String Username, String Password,String Text) throws IOException
	 {
	 	driver=initilizeDriver();
	 	driver.get(prop.getProperty("url"));
	 	Log.info("driver is working");
	 	homeObject o= new homeObject(driver);
	 assertEquals(o.gettitle().getText(), "Featured Courses");
	 	o.gettitle().getText();
Log.info("hello you are on navigation page");
}

	
}
