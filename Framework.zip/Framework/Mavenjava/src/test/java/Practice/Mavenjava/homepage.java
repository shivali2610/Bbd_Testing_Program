package Practice.Mavenjava;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import resources.Framework01;

public class homepage extends Framework01 {


	public WebDriver driver;

  public homepage() {
		// TODO Auto-generated constructor stub
	}
  
  
  public void setup() throws IOException{
		 driver=initilizeDriver();

  }


  @Test
  public void FrameworkNavigation() throws IOException {

	driver.get(prop.getProperty("url"));
	

	homeObject o= new homeObject(driver);
      o.getLogin().click();
	loginPage lp=new loginPage(driver);
	lp.getLogin().sendKeys("shivali2610");
	lp.getpassword().sendKeys("123456");
	lp.getLogin().click();
}

//public void teardown()

	//driver.close();
}
	

