package Practice.Mavenjava;

import static org.testng.Assert.assertEquals;

import java.io.IOException;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import resources.Framework01;

public class validateNavigateBar extends Framework01
{

	public static Logger Log=LogManager.getLogger(Framework01.class.getName());
	 public void FrameworkNavigation(String Username, String Password,String Text) throws IOException
	 {
	 	driver=initilizeDriver();
	 	driver.get(prop.getProperty("url"));
		
	 	homeObject o= new homeObject(driver);
	 assertEquals(o.gettitle().getText(), "java");
	 	o.gettitle().getText();
	 Log.info("you are on Navigationbar");
}
}
